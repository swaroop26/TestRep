export class Constants {

    public static REQ_USER_NAME='Username is required';
    public static REQ_PASSWORD='Password is required';


    public static LOGIN_API_URL='/api/login/';
    
    
 }