package com.lang;

import java.io.File;
import java.io.FileReader;
import java.util.Arrays;
import java.util.StringTokenizer;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;

@Component
/**
 * 
 * @author kranthiswaroop
 * 
 * It is the configuration class to read all the language files. It performs below steps
 * 1. Verifies if file name is valid
 * 2. Extracts the language name from file name
 * 3. If File name is valid it transfers the file to library to create one dictionary entry for each language file
 * 	eg: It creates one dictionary entry for French.1, French.2 language files  
 *
 */
public class ConfigLibrary { 
	
    private static final Log log = LogFactory.getLog(ConfigLibrary.class);
	
	private final String lettersRegex = "[a-zA-Z]+";
	private final String numbersRegex = "\\d+";
	
	@Autowired
	Library library ;

	public void config(){
		ClassLoader classLoader = getClass().getClassLoader();
		File filesFolder = new File(classLoader.getResource("LangFiles").getFile());
		
		this.readAllFiles(filesFolder);
	}
	
	public void readAllFiles(File filesFolder){
		for(File fileEntry :filesFolder.listFiles()){
			String language = getFileLanguage(fileEntry.getName());
			if(null != language) library.addDictionary(fileEntry, language);
		}
	}
	
	public String getFileLanguage(String fileName){
		if(validateFileName(fileName))
			return StringUtils.capitalize(fileName.toLowerCase().substring(0,fileName.indexOf(".")));
		else return null;
	}
	
	public boolean validateFileName(String fileName){
		StringTokenizer st = new StringTokenizer(fileName,".");
		
		if( (st.countTokens() !=2 ) 
				|| !Pattern.matches(lettersRegex, st.nextToken())
				|| !Pattern.matches(numbersRegex, st.nextToken()) ){
			
			log.error(" ConfigLibrary.validateFileName() : Invalid File Name found : " + fileName);
			return false;
		}
		return true;  
	} 
}
