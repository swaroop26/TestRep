package com.lang;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class App {
	
    private static final Log log = LogFactory.getLog(App.class);
	
	@Autowired
	ConfigLibrary configLibrary;
	
	@Autowired
	LanguageFinder languageFinder;
	
	public static String inputSting = "quod movet ad familiam";
	
	public static void main(String[] args) {
		
 		ApplicationContext context = new ClassPathXmlApplicationContext("SpringBeans.xml");
		App app = (App) context.getBean("app");
		app.findLanguage();
		
	}
	
	 public void findLanguage(){
		 configLibrary.config();
	 	 String language = languageFinder.findLanguage(inputSting);
	 	 log.info("***********************************");
	 	 log.info("***********************************");
	 	 log.info(" App.findLanguage() :  ------>> :" + language);
	 	 log.info("***********************************");
	 	 log.info("***********************************");

	 }
}
