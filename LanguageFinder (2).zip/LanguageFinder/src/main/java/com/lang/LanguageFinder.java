package com.lang;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.NavigableMap;
import java.util.TreeMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 
 * @author kranthi
 * 
 * LanguageFinder class finds the language by searching the input words,
 * from different language dictionaries stored in a library.
 * 
 * 1. it takes each word and searches in a language dictionary. 
 * 		If the words are found, then it saves the Language and words match count in predictionMap
 * 2. if it finds all words in any language dictionary then it reruns the language name.
 * 3. If not it returns the language name where it found most words
 * 4. If the words are not found in any language dictionary it returns null and logs error  
 *
 */
@Component
public class LanguageFinder {	 
	
    private static final Log log = LogFactory.getLog(LanguageFinder.class);

	
	@Autowired
	Library library;
	
	TreeMap<Integer, String> predictionMap ;
	
	public String findLanguage(String input){
		getPredictions(input.toLowerCase());
		if(predictionMap.isEmpty()){
			log.error(" LanguageFinder.findLanguage() :  Can't Find the Language");
			return null;
 		}else {
			NavigableMap<Integer, String> langMap = predictionMap.descendingMap();
			log.info(" LanguageFinder.findLanguage() :  " + langMap.firstEntry().getValue());
			return langMap.firstEntry().getValue();
 		}		 
	}
	
	public void getPredictions(String input){
		String[] words = input.split(" ");
		Map<String, Dictionary> dictonaryList= library.getDictionaryList();
	    Iterator<Entry<String, Dictionary>> iterator = dictonaryList.entrySet().iterator();
    	predictionMap = new TreeMap<Integer, String>();

	    while(iterator.hasNext()){
	    	int count =0;
	        Map.Entry<String, Dictionary> entry = iterator.next();
	        Dictionary dictonary = entry.getValue();
	        for(String word :words){
		        if(dictonary.getWords().contains(word))  count++;		        
	        }
	        if (count != 0)
	        	predictionMap.put(count, entry.getKey().toString());
	        
	        if(count == words.length) break;
	    }		
	}
	

}
