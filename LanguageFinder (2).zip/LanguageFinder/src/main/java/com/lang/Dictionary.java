package com.lang;

import java.util.HashSet;
import java.util.Set;

/**
 * 
 * @author kranthi
 * 
 * Dictonary is a pojo which saves Language and its words list.
 */
public class Dictionary {
	
	private String Language;
	private Set<String> words = new HashSet<String>();
	private Set<String> invalidWords  = new HashSet<String>();
	
	public String getLanguage() {
		return Language;
	}
	public void setLanguage(String language) {
		Language = language;
	}
	public Set<String> getWords() {
		return words;
	}
	public void setWords(Set<String> words) {
		this.words = words;
	}
	public Set<String> getInvalidWords() {
		return invalidWords;
	}
	public void setInvalidWords(Set<String> invalidWords) {
		this.invalidWords = invalidWords;
	}
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((Language == null) ? 0 : Language.hashCode());
		result = prime * result + ((invalidWords == null) ? 0 : invalidWords.hashCode());
		result = prime * result + ((words == null) ? 0 : words.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Dictionary other = (Dictionary) obj;
		if (Language == null) {
			if (other.Language != null)
				return false;
		} else if (!Language.equals(other.Language))
			return false;
		if (invalidWords == null) {
			if (other.invalidWords != null)
				return false;
		} else if (!invalidWords.equals(other.invalidWords))
			return false;
		if (words == null) {
			if (other.words != null)
				return false;
		} else if (!words.equals(other.words))
			return false;
		return true;
	}
	
	
	 


}
