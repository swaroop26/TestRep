package com.lang;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

/**
 * 
 * @author kranthiswaroop
 * 
 * FileUtil class reads a File and write its all valid words into a dictionary
 * 1. It skips the lines from a file if there are any invalid characters are present
 * 2. If the Line is valid it adds all the words into a set
 *
 */
@Component
public class FileUtil {
    private static final Log log = LogFactory.getLog(FileReader.class);

	
	@SuppressWarnings("resource")
	public void addWords(File file, Dictionary dictionary) throws FileNotFoundException, IOException{
			BufferedReader reader = new BufferedReader(new FileReader(file));
			String line = null;
			while ((line = reader.readLine()) != null) {
				line = line.toLowerCase();
				if(!line.isEmpty()){
					if(ValidateLine(line)){
						line = line.replaceAll("[\\.\\,\\;\\:]", " ");
						List<String> words = Arrays.asList(line.split(" "));
						dictionary.getWords().addAll(words);
					}else{
						dictionary.getInvalidWords().add(line);
					}
				}
 			}
			log.info(" FileUtil.addWords() : " + dictionary.getLanguage());
			log.info(" FileUtil.addWords() : Invalid words found in " + dictionary.getLanguage() + " file "
						+ dictionary.getInvalidWords()); 
		
	}
	
    public boolean ValidateLine(String line){ 
    	return Pattern.matches("^[a-zA-Z \\.\\,\\;\\:]+$", line);  
    }
    
	 
	
}
