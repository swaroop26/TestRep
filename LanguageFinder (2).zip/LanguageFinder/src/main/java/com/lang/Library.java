package com.lang;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component

/**
 * 
 * @author kranthi
 * 
 *  Library holds list of dictionaries. 
 *  addDictionary reads words from a file and adds all words to a dictionary if exisit or else creates new one
 *
 */
public class Library { 
	
    private static final Log log = LogFactory.getLog(Library.class);

	private Map<String, Dictionary> dictionaryList = new HashMap<String, Dictionary>();
	
	@Autowired
	FileUtil fileUtil;

	public Map<String,Dictionary> getDictionaryList() {
		return dictionaryList;
	}
	
	public void addDictionary(File file, String language){
		Dictionary dictonary;
		if(dictionaryList.containsKey(language)){
			dictonary = dictionaryList.get(language);
		}else{
			dictonary = new Dictionary();
			dictonary.setLanguage(language);
		}		
		try {
			fileUtil.addWords(file, dictonary);
		} catch (FileNotFoundException e) {
			log.error(" Library.addDictonary(): " + e.getMessage());
		} catch (IOException e) {
			log.error(" Library.addDictonary(): " + e.getMessage());
		}
		dictionaryList.put(language, dictonary);
	}
 
}
