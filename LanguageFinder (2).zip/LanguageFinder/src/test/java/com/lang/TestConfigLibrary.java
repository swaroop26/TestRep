package com.lang;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.lang.ConfigLibrary;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/SpringBeans.xml"})
public class TestConfigLibrary {
	
	@Autowired
	ConfigLibrary configLibrary;
	
	@Test
	public void testValidateFileName(){
		Assert.assertFalse(configLibrary.validateFileName("Junk.1.2"));
		Assert.assertFalse(configLibrary.validateFileName("Junk12.2"));
		Assert.assertFalse(configLibrary.validateFileName("Junk.1j"));
		Assert.assertFalse(configLibrary.validateFileName("Junk"));
		Assert.assertTrue(configLibrary.validateFileName("frEnch.2"));
		Assert.assertTrue(configLibrary.validateFileName("Test.10"));
	}
	
	@Test
	public void testGetFileLanguage(){
		Assert.assertEquals(configLibrary.getFileLanguage("frEnch.2"),"French");
		Assert.assertEquals(configLibrary.getFileLanguage("TEST.10"),"Test");
		Assert.assertNull(configLibrary.getFileLanguage("Junk.1.2"));
		Assert.assertNull(configLibrary.getFileLanguage("Junk"));
	}

}
