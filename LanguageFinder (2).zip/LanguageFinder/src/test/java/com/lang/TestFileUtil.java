package com.lang;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.lang.Dictionary;
import com.lang.FileUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/SpringBeans.xml"})
public class TestFileUtil {
	
	@Autowired
	FileUtil fileUtil;

	
	@Test(expected=FileNotFoundException.class)
	public void testaddWordsException() throws FileNotFoundException, IOException {
			
		File file = new File("/LangFiles/Sample.1");
		fileUtil.addWords(file, new Dictionary()); 
	}
	
	@Test
	public void testaddWords() throws FileNotFoundException, IOException {
			
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("LangFiles/English.2").getFile());
		Dictionary dictonary = new Dictionary();
		
		fileUtil.addWords(file, dictonary); 
		Assert.assertEquals(dictonary, getDictonary());

	}
	
	@Test
	public void testaddWordsInvalidTxt() throws FileNotFoundException, IOException {
			
		ClassLoader classLoader = getClass().getClassLoader();
		File file = new File(classLoader.getResource("LangFiles/InvlidText.13").getFile());
		Dictionary dictonary = new Dictionary();
		
		fileUtil.addWords(file, dictonary); 
		Assert.assertEquals(dictonary, getInvalidDictonary());

	}
	
	public Dictionary getDictonary(){
		Dictionary dictonary = new Dictionary();
		dictonary.getWords().add("sample");
		dictonary.getWords().add("text");
		return dictonary;
	}
	
	public Dictionary getInvalidDictonary(){
		
		Dictionary dictonary = new Dictionary();
		dictonary.getWords().add("invalid");
		dictonary.getWords().add("text");
		dictonary.getInvalidWords().add("txt*(#n");
		
		return dictonary;
	}

}
