package com.lang;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.lang.ConfigLibrary;
import com.lang.LanguageFinder;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"/SpringBeans.xml"})
public class TestLanguageFinder {
	
	@Autowired
	ConfigLibrary configLibrary;
	
	@Autowired
	LanguageFinder languageFinder;
	
		
	@Before
	public void init(){
		 configLibrary.config();
	}
		
	
	@Test
	public void testLanguage(){
		Assert.assertEquals(languageFinder.findLanguage("They have all"),"English");
		Assert.assertEquals(languageFinder.findLanguage("cum non possit esse"),"Latin");
		Assert.assertEquals(languageFinder.findLanguage("un punto de acceso"),"Spanish");
		Assert.assertEquals(languageFinder.findLanguage("doigh liom go bhfuil"),"Irish");
		Assert.assertEquals(languageFinder.findLanguage("Ce premier feu de foret"),"French");
		Assert.assertNull(languageFinder.findLanguage("g8S(JHKHJS;SF%&$U&#*&#_%$"));
	}
	
	
	

}
